package com.devsu.hackerearth.backend.account.mapper;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;

public class TransactionMapper {

    public static TransactionDto toDto(Transaction t) {
        return new TransactionDto(
                t.getId(),
                t.getDate(),
                t.getType(),
                t.getAmount(),
                t.getBalance(),
                t.getAccountId()
        );
    }

    public static Transaction toEntity(TransactionDto dto) {
        Transaction t = new Transaction();
        t.setId(dto.getId());
        t.setDate(dto.getDate());
        t.setType(dto.getType());
        t.setAmount(dto.getAmount());
        t.setBalance(dto.getBalance());
        t.setAccountId(dto.getAccountId());
        return t;
    }
}
