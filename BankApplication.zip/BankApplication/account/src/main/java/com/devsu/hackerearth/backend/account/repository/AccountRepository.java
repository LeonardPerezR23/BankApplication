package com.devsu.hackerearth.backend.account.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

    boolean existsByNumber(String number);

    Optional<Account> findByNumber(String number);

    @Query("SELECT new com.devsu.hackerearth.backend.account.model.dto.BankStatementDto(" +
    " t.date, a.clientId, a.number, a.type, a.initialAmount, a.isActive, t.type, t.amount, t.balance ) " +
    "FROM Account a, Transaction t " +
    "WHERE t.accountId = a.id " +
    "  AND a.clientId = :clientId " +
    "  AND t.date >= :dateTransactionStart AND t.date <= :dateTransactionEnd " +
    "ORDER BY t.date")
    List<BankStatementDto> findBankStatements(
            @Param("clientId") Long clientId,
            @Param("dateTransactionStart") Date dateTransactionStart,
            @Param("dateTransactionEnd") Date dateTransactionEnd);

}
