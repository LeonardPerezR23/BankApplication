package com.devsu.hackerearth.backend.account.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Account extends Base {
    
    @Column(unique = true, nullable = false)
    private String number;
	private String type;
	private double initialAmount;
	private boolean isActive;

    @Column(name = "client_id", nullable = false)
    private Long clientId;
}
