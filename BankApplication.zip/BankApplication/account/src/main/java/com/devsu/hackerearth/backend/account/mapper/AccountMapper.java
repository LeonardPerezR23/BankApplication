package com.devsu.hackerearth.backend.account.mapper;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;

public class AccountMapper {

    public static AccountDto toDto(Account a) {
        return new AccountDto(
            a.getId(),
            a.getNumber(),
            a.getType(),
            a.getInitialAmount(),
            a.isActive(),
            a.getClientId()
        );
    }

    public static Account toEntity(AccountDto dto) {
        Account a = new Account();
        a.setId(dto.getId());
        a.setNumber(dto.getNumber());
        a.setType(dto.getType());
        a.setInitialAmount(dto.getInitialAmount());
        a.setActive(dto.isActive());
        a.setClientId(dto.getClientId());
        return a;
    }
}
