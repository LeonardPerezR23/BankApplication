package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.exception.CuentaNoEncontradaException;
import com.devsu.hackerearth.backend.account.exception.FondosInsuficientesException;
import com.devsu.hackerearth.backend.account.exception.TipoTransaccionInvalidoException;
import com.devsu.hackerearth.backend.account.exception.TransaccionNoEncontradaException;
import com.devsu.hackerearth.backend.account.mapper.TransactionMapper;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.devsu.hackerearth.backend.account.service.Utils.DateUtils;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    public TransactionServiceImpl(TransactionRepository transactionRepository, AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
    }

    @Override
    public List<TransactionDto> getAll() {
        return transactionRepository.findAll()
                .stream()
                .map(TransactionMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        return transactionRepository.findById(id)
                .map(TransactionMapper::toDto)
                .orElseThrow(() -> new TransaccionNoEncontradaException(id));
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {

        Account account = accountRepository.findById(transactionDto.getAccountId())
                .orElseThrow(() -> new CuentaNoEncontradaException(transactionDto.getAccountId()));

        double currentBalance = account.getInitialAmount();
        Transaction lastTransaction = transactionRepository.findTopByAccountIdOrderByDateDesc(account.getId());
        if (lastTransaction != null) {
            currentBalance = lastTransaction.getBalance();
        }

        double newBalance;
        switch (transactionDto.getType().toUpperCase()) {
            case "DEPOSITO":
                newBalance = currentBalance + transactionDto.getAmount();
                break;
            case "RETIRO":
                if (transactionDto.getAmount() > currentBalance) {
                    throw new FondosInsuficientesException();
                }
                newBalance = currentBalance - transactionDto.getAmount();
                break;
            default:
                throw new TipoTransaccionInvalidoException(transactionDto.getType());
        }

        Transaction transaction = TransactionMapper.toEntity(transactionDto);
        transaction.setId(null);
        transaction.setDate(new Date());
        transaction.setBalance(newBalance);

         return TransactionMapper.toDto(transactionRepository.save(transaction));
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
            dateTransactionEnd = DateUtils.atEndOfDay(dateTransactionEnd);
               
            List<BankStatementDto> report = accountRepository.findBankStatements(clientId, dateTransactionStart, dateTransactionEnd);

            adjustInitialAmounts(report);
        
            return report;
        }
   


    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        Transaction transaction = transactionRepository.findTopByAccountIdOrderByDateDesc(accountId);
        if (transaction == null) {
            throw new TransaccionNoEncontradaException(accountId);
        }
        return TransactionMapper.toDto(transaction);
    }

    private void adjustInitialAmounts(List<BankStatementDto> report) {
        for (int i = 1; i < report.size(); i++) {
            report.get(i).setInitialAmount(report.get(i - 1).getBalance());
        }
    }
   

 
    
}
