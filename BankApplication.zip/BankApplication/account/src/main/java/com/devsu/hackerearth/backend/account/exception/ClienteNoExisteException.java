package com.devsu.hackerearth.backend.account.exception;

public class ClienteNoExisteException extends RuntimeException {
    public ClienteNoExisteException(Long clientId) {
        super("El cliente con ID " + clientId + " no existe o el servicio de clientes no está disponible");
    }
}