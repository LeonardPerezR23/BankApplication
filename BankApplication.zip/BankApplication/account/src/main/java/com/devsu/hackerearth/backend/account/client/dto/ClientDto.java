package com.devsu.hackerearth.backend.account.client.dto;

import lombok.Data;

@Data
public class ClientDto {
    private Long id;
    private String name;
    private String dni;
}
