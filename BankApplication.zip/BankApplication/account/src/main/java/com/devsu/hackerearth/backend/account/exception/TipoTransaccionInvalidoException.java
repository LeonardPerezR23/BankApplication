package com.devsu.hackerearth.backend.account.exception;

public class TipoTransaccionInvalidoException extends RuntimeException {
    public TipoTransaccionInvalidoException(String tipo) {
        super("Solo se permiten DEPOSITO Y RETIRO. Su tipo de transacción es inválido: " + tipo );
    }
}