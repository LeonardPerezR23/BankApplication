package com.devsu.hackerearth.backend.account.exception;

public class FondosInsuficientesException extends RuntimeException {
    public FondosInsuficientesException() {
        super("Fondos insuficientes para realizar el retiro.");
    }
}