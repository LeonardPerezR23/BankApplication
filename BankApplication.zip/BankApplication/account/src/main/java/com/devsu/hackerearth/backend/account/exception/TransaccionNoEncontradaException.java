package com.devsu.hackerearth.backend.account.exception;

public class TransaccionNoEncontradaException extends RuntimeException {
    public TransaccionNoEncontradaException(Long id) {
        super("No se encontró la transacción con id " + id);
    }
}