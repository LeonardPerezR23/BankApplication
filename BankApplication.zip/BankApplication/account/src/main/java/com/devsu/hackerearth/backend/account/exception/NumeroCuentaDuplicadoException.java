package com.devsu.hackerearth.backend.account.exception;

public class NumeroCuentaDuplicadoException extends RuntimeException {
    public NumeroCuentaDuplicadoException(String numero) {
        super("El número de cuenta ya está registrado: " + numero);
    }
}