package com.devsu.hackerearth.backend.account.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.devsu.hackerearth.backend.account.client.dto.ClientDto;

@FeignClient(name = "client-service", url = "${client.service.url}")
public interface ClientFeignClient {

    @GetMapping("/api/clients/{id}")
    ClientDto getClientById(@PathVariable("id") Long id);
}
