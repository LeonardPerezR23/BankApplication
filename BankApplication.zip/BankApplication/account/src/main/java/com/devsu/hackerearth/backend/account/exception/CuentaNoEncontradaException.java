package com.devsu.hackerearth.backend.account.exception;

public class CuentaNoEncontradaException extends RuntimeException {
    public CuentaNoEncontradaException(Long id) {
        super("No se encontró la cuenta con id " + id);
    }
}

