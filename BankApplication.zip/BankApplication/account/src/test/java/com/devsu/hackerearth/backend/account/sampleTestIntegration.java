package com.devsu.hackerearth.backend.account;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@SpringBootTest
@Transactional
public class sampleTestIntegration {

    @Autowired
    private AccountRepository accountRepository;

    @Test
    void accountRepositoryIntegrationTest() {
        // Arrange
        Account account = new Account();
        account.setNumber("12345");
        account.setType("savings");
        account.setInitialAmount(500.0);
        account.setActive(true);
        account.setClientId(1L);

        // Act
        Account savedAccount = accountRepository.save(account);

        // Assert
        assertNotNull(savedAccount.getId(), "El ID no debe ser nulo después de guardar");
        Account found = accountRepository.findById(savedAccount.getId()).orElse(null);
        assertNotNull(found, "Debe encontrarse la cuenta en la base de datos");
        assertEquals("12345", found.getNumber());
        assertEquals("savings", found.getType());
        assertEquals(500.0, found.getInitialAmount());
        assertEquals(true, found.isActive());
        assertEquals(1L, found.getClientId());
    }
}