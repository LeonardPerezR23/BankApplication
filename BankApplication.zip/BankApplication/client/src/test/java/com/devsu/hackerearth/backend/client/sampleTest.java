package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;

@SpringBootTest
public class sampleTest {

    private ClientService clientService = mock(ClientService.class);
    private ClientController clientController = new ClientController(clientService);

    @Test
    void createClientTest() {
        ClientDto newClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", true);
        ClientDto createdClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999",
                true);
        when(clientService.create(newClient)).thenReturn(createdClient);

        ResponseEntity<ClientDto> response = clientController.create(newClient);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(createdClient, response.getBody());
    }

    @Test
    void clientEntityTest() {
        Client client = new Client();
        client.setId(1L);
        client.setDni("123456789");
        client.setName("Leonardo Pérez");
        client.setPassword("clave123");
        client.setGender("M");
        client.setAge(30);
        client.setAddress("Calle Falsa 123");
        client.setPhone("3114473020");
        client.setActive(true);

        assertEquals(1L, client.getId());
        assertEquals("123456789", client.getDni());
        assertEquals("Leonardo Pérez", client.getName());
        assertEquals("clave123", client.getPassword());
        assertEquals("M", client.getGender());
        assertEquals(30, client.getAge());
        assertEquals("Calle Falsa 123", client.getAddress());
        assertEquals("3114473020", client.getPhone());
        assertEquals(true, client.isActive());
    }
}