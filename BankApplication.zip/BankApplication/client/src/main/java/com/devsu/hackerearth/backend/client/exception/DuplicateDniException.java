package com.devsu.hackerearth.backend.client.exception;

public class DuplicateDniException extends RuntimeException {
    public DuplicateDniException(String dni) {
        super("El DNI ya está registrado: " + dni);
    }
}