package com.devsu.hackerearth.backend.client.mapper;


import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;

public class ClientMapper {

    private ClientMapper() {
       
    }

    public static ClientDto toDto(Client c) {
        return new ClientDto(
                c.getId(),
                c.getDni(),
                c.getName(),
                c.getPassword(),
                c.getGender(),
                c.getAge(),
                c.getAddress(),
                c.getPhone(),
                c.isActive()
        );
    }

    public static Client toEntity(ClientDto dto) {
        Client c = new Client();
        c.setId(dto.getId());
        c.setDni(dto.getDni());
        c.setName(dto.getName());
        c.setPassword(dto.getPassword());
        c.setGender(dto.getGender());
        c.setAge(dto.getAge());
        c.setAddress(dto.getAddress());
        c.setPhone(dto.getPhone());
        c.setActive(dto.isActive());
        return c;
    }
}