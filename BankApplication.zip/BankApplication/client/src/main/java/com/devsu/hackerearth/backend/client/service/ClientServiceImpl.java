package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import com.devsu.hackerearth.backend.client.exception.ClientNotFoundException;
import com.devsu.hackerearth.backend.client.exception.DuplicateDniException;
import com.devsu.hackerearth.backend.client.exception.InvalidClientDataException;
import com.devsu.hackerearth.backend.client.mapper.ClientMapper;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}



	@Override
	public List<ClientDto> getAll() {
		return clientRepository.findAll()
				.stream()
				.map(ClientMapper::toDto)
				.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		return clientRepository.findById(id)
		.map(ClientMapper::toDto)
		.orElseThrow(() -> new ClientNotFoundException(id));
	}


	@Override
	public ClientDto create(ClientDto clientDto) {
		if (clientRepository.existsByDni(clientDto.getDni())) {
			throw new DuplicateDniException(clientDto.getDni());
		}
		Client client = ClientMapper.toEntity(clientDto);
		client.setId(null);
		return ClientMapper.toDto(clientRepository.save(client));
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		if (clientDto.getId() == null) {
			throw new InvalidClientDataException("El ID del cliente es obligatorio para actualizar.");
		}
		if (!clientRepository.existsById(clientDto.getId())) {
			throw new ClientNotFoundException(clientDto.getId());
		}
		Client client = ClientMapper.toEntity(clientDto);
		return ClientMapper.toDto(clientRepository.save(client));
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
	      Client client = clientRepository.findById(id)
                .orElseThrow(() -> new ClientNotFoundException(id));
        client.setActive(partialClientDto.isActive());
        return ClientMapper.toDto(clientRepository.save(client));
    }

	@Override
	public void deleteById(Long id) {
		if (!clientRepository.existsById(id)){
			throw new ClientNotFoundException(id);
		}
		clientRepository.deleteById(id);
	}
}
