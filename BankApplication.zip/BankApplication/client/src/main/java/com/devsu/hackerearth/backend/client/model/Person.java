package com.devsu.hackerearth.backend.client.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@MappedSuperclass
public class Person extends Base {
	private String name;
	@Column(unique = true, nullable = false)
	private String dni;
	private String gender;
	private int age;
	private String address;
	private String phone;
}
